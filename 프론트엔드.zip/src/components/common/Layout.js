//전체 레이아웃 

import styled from 'styled-components'


 
export const Layout= styled.div`
width: 100%;
max-width: 430px;
margin: auto;
min-height: 100vh;
background: white;

`;





