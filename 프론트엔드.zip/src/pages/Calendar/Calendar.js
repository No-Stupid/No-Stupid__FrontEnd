import React, { useState, useEffect } from 'react';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import axios from 'axios';
import '../../css/Calendar.css';
import Modal from 'react-modal';

const localizer = momentLocalizer(moment);

Modal.setAppElement('#root');

const CalendarComponent = () => {
    const [events, setEvents] = useState([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedDate, setSelectedDate] = useState(null);
    const [enteredText, setEnteredText] = useState('');
    const [isEditing, setIsEditing] = useState(false);
    const [editEventId, setEditEventId] = useState(null);

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const response = await axios.get('http://localhost:8080/api/calendarList');
            setEvents(response.data.map(event => ({
                id: event.id,
                start: new Date(event.date),
                end: new Date(event.date),
                title: event.text,
            })));
        } catch (error) {
            console.error(error);
        }
    };

    const handleSelect = ({ start, id }) => {
        const formattedDate = moment(start).format('YYYY.MM.DD');
        console.log('Selected date:', formattedDate);
        setSelectedDate(formattedDate);
        setEnteredText('');
        setIsEditing(false);
        setEditEventId(null);
        setIsModalOpen(true);
    };

    const handleEdit = (event) => {
        setSelectedDate(moment(event.start).format('YYYY.MM.DD'));
        setEnteredText(event.title);
        setIsEditing(true);
        setEditEventId(event.id);
        setIsModalOpen(true);
    };

    const handleDelete = async () => {
        try {
            if (editEventId) {
                await axios.delete(`http://localhost:8080/api/calendar/delete/${editEventId}`);
                fetchData(); // Refresh events after deleting
                setIsModalOpen(false);
            }
        } catch (error) {
            console.error(error);
        }
    };

    const closeModal = () => {
        console.log('Modal closed');
        setIsModalOpen(false);
    };

    const handleTextSubmit = async (text) => {
        try {
            const formattedDate = moment(selectedDate, 'YYYY.MM.DD').toISOString();

            if (isEditing) {
                await axios.put(`http://localhost:8080/api/calendar/edit/${editEventId}`, {
                    date: formattedDate,
                    text,
                });
            } else {
                await axios.post('http://localhost:8080/api/calendar', {
                    date: formattedDate,
                    text,
                });
            }

            fetchData();
            setIsModalOpen(false);
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <div className='page_'>
            <Calendar
                localizer={localizer}
                events={events}
                startAccessor="start"
                endAccessor="end"
                onSelectSlot={handleSelect}
                onSelectEvent={handleEdit}
                selectable
                style={{ height: 500, zIndex: 0 }}
            />

            <Modal
                style={{
                    overlay: {
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: 1000,
                    },
                    content: {
                        backgroundColor: 'white',
                        zIndex: 1001,
                    },
                }}
                isOpen={isModalOpen}
                onRequestClose={closeModal}
                contentLabel="Text Input Modal"
            >
                <div>
                    <h2>{selectedDate}</h2>
                    <input
                        className='in_Input'
                        placeholder="내용 입력"
                        value={enteredText}
                        onChange={(e) => setEnteredText(e.target.value)}
                    />
                    <br />
                    <button style={{}} onClick={() => handleTextSubmit(enteredText)}>
                        {isEditing ? '수정' : '완료'}
                    </button>
                    {isEditing && (
                        <button style={{ marginLeft: '10px' }} onClick={handleDelete}>
                            삭제
                        </button>
                    )}
                </div>
            </Modal>
        </div>
    );
};

export default CalendarComponent;
