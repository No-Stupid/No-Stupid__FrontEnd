import React, { useState, useEffect } from 'react';
import { HomeLayout } from 'pages/home/style';
import styled from 'styled-components';
import GoBackIcon from 'components/icons/GobackIcon';
import Underscore from 'components/Underscore';
import InputBox, { InputContainer, InputLayout, InputTitle } from 'components/form/InputBox';
import TextAreaBox from 'components/form/TextAreaBox';
import RadioButton from 'components/form/RadioButton';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';

const infoInitData = {
  companyName: '',
  role: '',
  qualification: '',
  homePageUrl: '',
  salary: 0,
  companyTalent: '',
  applyCheck: false,
  documentCheck: false,
  interviewCheck: false,
  question: '',
  memo: '',
  pass: false,
};

const CorporateInfo = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const { pathname, search } = location;
  const splitPathname = pathname.split('/');
  const modifyIndex = new URLSearchParams(search).get('id');
  const hasId = new URLSearchParams(search).get('id');
  const isModify = Boolean(hasId);
  const companyId = parseInt(hasId, 10);

  const [companies, setCompanies] = useState([]);
  const [info, setInfo] = useState(infoInitData);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:8080/api/applyList');
        setCompanies(response.data);
  
        if (isModify && companyId) {
          const modifiedInfo = response.data.find((item) => item.id === companyId);
          console.log(modifiedInfo);
          if (modifiedInfo) {
            setInfo(modifiedInfo);
  
            setInfo((prevInfo) => ({
              ...prevInfo,
              documentCheck: modifiedInfo.documentCheck === 'true',
              interviewCheck: modifiedInfo.interviewCheck === 'true',
              pass: modifiedInfo.pass === 'true',
              applyCheck: modifiedInfo.applyCheck === 'true',
            }));
          }
        }
      } catch (error) {
        console.error(error);
      }
    };
  
    fetchData();
  }, [isModify]);      

  const handleSubmission = async () => {
    try {
      const postData = {
        companyName: info.companyName,
        role: info.role,
        qualification: info.qualification,
        homePageUrl: info.homePageUrl,
        salary: info.salary,
        applyCheck: info.applyCheck,
        question: info.question,
        documentCheck: info.documentCheck,
        interviewCheck: info.interviewCheck,
        companyTalent: info.companyTalent,
        member: info.member,
        memo: info.memo,
        pass: info.pass,
      };
  
      const userId = 123;
  
      if (isModify) {
        console.log(postData);
        await axios.put(`http://localhost:8080/api/applyInfo/edit/${modifyIndex}`, postData);
      } else {
        await axios.post(`http://localhost:8080/api/applyInfo?userId=${userId}`, postData);
      }
  
      navigate(-1);
    } catch (error) {
      console.error(error);
    }
  };   

  return (
    <HomeLayout>
      <Container>
        <div onClick={() => navigate(-1)}>
          <GoBackIcon size={20} />
        </div>
        <Title>기업 정보</Title>
        <Underscore />
        <Main>
          <InputBox title={'기업명'} value={info.companyName} setValue={e => setInfo({ ...info, companyName: e.target.value })} />
          <InputBox title={'직무'} value={info.role} setValue={e => setInfo({ ...info, role: e.target.value })} />
          <InputBox title={'자격요건'} value={info.qualification} setValue={e => setInfo({ ...info, qualification: e.target.value })} />
          <InputContainer>
            <InputTitle>
              지원 여부
            </InputTitle>
            <DeadLineBox>
              <InputLayout>
                <BoxRadio>
                  <InputDiv>
                    <RadioButton
                      isOn={info.applyCheck}
                      title={'지원완료'}
                      setIsOn={() => setInfo({ ...info, applyCheck: true })}
                    />
                  </InputDiv>
                  <InputDiv>
                    <RadioButton
                      isOn={!info.applyCheck}
                      title={'지원예정'}
                      setIsOn={() => setInfo({ ...info, applyCheck: false })}
                    />
                  </InputDiv>
                </BoxRadio>
              </InputLayout>
            </DeadLineBox>
          </InputContainer>
          <InputBox title={'기업 홈페이지'} value={info.homePageUrl} setValue={e => setInfo({ ...info, homePageUrl: e.target.value })} />
          <InputBox title={'연봉'} value={info.salary} setValue={e => setInfo({ ...info, salary: e.target.value })} />
          <TextAreaBox title={'기업 인재상'} value={info.companyTalent} setValue={e => setInfo({ ...info, companyTalent: e.target.value })} />
          <InputContainer>
            <InputTitle>
              서류
            </InputTitle>
            <DeadLineBox>
              <InputLayout>
                <BoxRadio>
                  <InputDiv>
                    <RadioButton isOn={info.documentCheck} title={'합격'} setIsOn={() => setInfo({ ...info, documentCheck: true })} />
                  </InputDiv>
                  <InputDiv>
                    <RadioButton isOn={!info.documentCheck} title={'불합격'} setIsOn={() => setInfo({ ...info, documentCheck: false })} />
                  </InputDiv>
                </BoxRadio>
              </InputLayout>
            </DeadLineBox>
          </InputContainer>
          <InputContainer>
            <InputTitle>
              면접
            </InputTitle>
            <DeadLineBox>
              <InputLayout>
                <BoxRadio>
                  <InputDiv>
                    <RadioButton isOn={info.interviewCheck} title={'합격'} setIsOn={() => setInfo({ ...info, interviewCheck: true })} />
                  </InputDiv>
                  <InputDiv>
                    <RadioButton isOn={!info.interviewCheck} title={'불합격'} setIsOn={() => setInfo({ ...info, interviewCheck: false })} />
                  </InputDiv>
                </BoxRadio>
              </InputLayout>
            </DeadLineBox>
          </InputContainer>
          <TextAreaBox title={'면접 질문'} value={info.question} setValue={e => setInfo({ ...info, question: e.target.value })} />
          <InputContainer>
            <InputTitle>
              합격 여부
            </InputTitle>
            <DeadLineBox>
              <InputLayout>
                <BoxRadio>
                  <InputDiv>
                    <RadioButton
                      isOn={info.pass}
                      title={'합격'}
                      setIsOn={() => setInfo({ ...info, pass: true })}
                    />
                  </InputDiv>
                  <InputDiv>
                    <RadioButton
                      isOn={!info.pass}
                      title={'불합격'}
                      setIsOn={() => setInfo({ ...info, pass: false })}
                    />
                  </InputDiv>
                </BoxRadio>
              </InputLayout>
            </DeadLineBox>
          </InputContainer>
          <TextAreaBox title={'회고란'} value={info.memo} setValue={e => setInfo({ ...info, memo: e.target.value })} />
        </Main>
      </Container>

      <ButtonBox>
        <SubmitButton onClick={handleSubmission}>{isModify ? '수정' : '완료'}</SubmitButton>
      </ButtonBox>
    </HomeLayout>
  );
};

const ButtonBox = styled.div`
  display: flex;
  justify-content: center;
`
const SubmitButton = styled.button.attrs(props => ({
  type: 'submit'
}))`
  width: 50%;
  padding: 10px 20px;
  border-radius: 12px;
`

const BoxRadio = styled.div`
  display: flex;
  justify-content: space-around;
  padding: 6px 0;
`

const Main = styled.main`
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-top: 10px;
`

export const InputDiv = styled.div`
  display: flex;
  justify-content: space-between;
`

const Container = styled.div`
  padding: 20px;
`

const TextInput = styled.input`
  
`

export const DeadLineBox = styled.div`
  display: flex;
  gap: 8px;
`

const Title = styled.h1`
  font-size: 20px;
  padding: 14px 0;
`

export default CorporateInfo;
